import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-3',
  templateUrl: './books-3.component.html',
  styleUrls: ['./books-3.component.css']
})
export class Books3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

