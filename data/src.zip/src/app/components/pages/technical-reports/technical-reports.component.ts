import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technical-reports',
  templateUrl: './technical-reports.component.html',
  styleUrls: ['./technical-reports.component.css']
})
export class TechnicalReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

