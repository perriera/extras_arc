import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-8',
  templateUrl: './books-8.component.html',
  styleUrls: ['./books-8.component.css']
})
export class Books8Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

