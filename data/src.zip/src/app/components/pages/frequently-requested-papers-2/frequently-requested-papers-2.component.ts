import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frequently-requested-papers-2',
  templateUrl: './frequently-requested-papers-2.component.html',
  styleUrls: ['./frequently-requested-papers-2.component.css']
})
export class FrequentlyRequestedPapers2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

