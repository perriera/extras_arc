import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-bjarne-stroustrup',
  templateUrl: './about-bjarne-stroustrup.component.html',
  styleUrls: ['./about-bjarne-stroustrup.component.css']
})
export class AboutBjarneStroustrupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

