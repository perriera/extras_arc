import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-by-bjarne-stroupstrup',
  templateUrl: './books-by-bjarne-stroupstrup.component.html',
  styleUrls: ['./books-by-bjarne-stroupstrup.component.css']
})
export class BooksByBjarneStroupstrupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

