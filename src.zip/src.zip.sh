cp testit/src.zip testit/src.zip
cd testit/
zip -r ../src.zip . >/dev/null
