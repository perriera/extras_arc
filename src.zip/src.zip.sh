cd build/
zip -r /tmp/temp.zip . >/dev/null
cp /tmp/temp.zip "/home/perry/Projects/extras_arc/build/src.zip">/dev/null
rm /tmp/temp.zip>/dev/null
