cd build/
zip -r ../src.zip . >/dev/null
